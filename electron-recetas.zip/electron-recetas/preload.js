const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('apiFavoritos', {
  obtenerFavoritos: () => ipcRenderer.invoke('favoritos:obtener'),
  agregarFavorito: (receta) => ipcRenderer.invoke('favoritos:agregar', receta),
  quitarFavorito: (idMeal) => ipcRenderer.invoke('favoritos:quitar', idMeal),
  esFavorito: (idMeal) => ipcRenderer.invoke('favoritos:esFavorito', idMeal)
});
