function mostrarDetalles(id) {
  obtenerRecetaPorId(id).then(receta => {
    const cont = document.getElementById("contenido");
    if (!receta) return cont.innerHTML = "<p>Error al cargar la receta.</p>";

    cont.innerHTML = `
      <div class="card">
        <h2>${receta.strMeal}</h2>
        <img src="${receta.strMealThumb}">
        <p><b>Categoría:</b> ${receta.strCategory}</p>
        <p><b>Instrucciones:</b> ${receta.strInstructions}</p>
        <button class="btn" id="btn-agregar">Añadir a Favoritos</button>
        <button class="btn" onclick="cargarInicio()">Volver</button>
      </div>
    `;

    document.getElementById("btn-agregar").onclick = () => {
      guardarFavorito(receta);
      alert("Agregado a favoritos");
    };
  });
}
