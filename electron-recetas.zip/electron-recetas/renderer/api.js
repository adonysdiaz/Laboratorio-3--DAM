const API = "https://www.themealdb.com/api/json/v1/1";

function obtenerRecetasRandom() {
  return fetch(`${API}/random.php`)
    .then(res => res.json())
    .then(data => data.meals || [])
    .catch(err => { console.error(err); return []; });
}

function obtenerRecetaPorId(id) {
  return fetch(`${API}/lookup.php?i=${id}`)
    .then(res => res.json())
    .then(data => data.meals ? data.meals[0] : null)
    .catch(err => { console.error(err); return null; });
}
