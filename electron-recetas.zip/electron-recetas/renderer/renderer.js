window.onload = () => cargarInicio();

document.getElementById("btn-inicio").onclick = cargarInicio;
document.getElementById("btn-favoritos").onclick = cargarFavoritos;

function cargarInicio() {
  const cont = document.getElementById("contenido");
  cont.innerHTML = "<h2>Cargando recetas...</h2>";

  // Llamar 6 veces para mostrar 6 recetas random
  const promesas = [];
  for (let i = 0; i < 6; i++) {
    promesas.push(obtenerRecetasRandom());
  }

  Promise.all(promesas).then(resultados => {
    // 'resultados' es un array de arrays, aplanamos
    const recetas = resultados.flat();

    cont.innerHTML = recetas.map(r => `
      <div class="card">
        <h3>${r.strMeal}</h3>
        <img src="${r.strMealThumb}">
        <button class="btn" onclick="mostrarDetalles('${r.idMeal}')">Ver Detalles</button>
      </div>
    `).join("");
  });
}


function cargarFavoritos() {
  const cont = document.getElementById("contenido");
  const favs = obtenerFavoritos();

  if (favs.length === 0) {
    cont.innerHTML = "<h3>No hay favoritos</h3>";
    return;
  }

  cont.innerHTML = favs.map(r => `
    <div class="card">
      <h3>${r.strMeal}</h3>
      <img src="${r.strMealThumb}">
      <button class="btn" onclick="mostrarDetalles('${r.idMeal}')">Ver Detalles</button>
      <button class="btn" onclick="eliminarFavorito('${r.idMeal}'); cargarFavoritos();">Eliminar</button>
    </div>
  `).join("");
}

