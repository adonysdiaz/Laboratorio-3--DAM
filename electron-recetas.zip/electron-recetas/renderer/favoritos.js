function obtenerFavoritos() {
  return JSON.parse(localStorage.getItem("favoritos") || "[]");
}

function guardarFavorito(receta) {
  const lista = obtenerFavoritos();
  if (!lista.find(r => r.idMeal === receta.idMeal)) {
    lista.push(receta);
    localStorage.setItem("favoritos", JSON.stringify(lista));
  }
}

function eliminarFavorito(id) {
  let lista = obtenerFavoritos();
  lista = lista.filter(r => r.idMeal !== id);
  localStorage.setItem("favoritos", JSON.stringify(lista));
}
