const { app, BrowserWindow } = require("electron");
const path = require("path");

function crearVentana() {
  const ventana = new BrowserWindow({
    width: 900,
    height: 700,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  ventana.loadFile(path.join(__dirname, "renderer", "index.html"));
}

app.whenReady().then(crearVentana);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
